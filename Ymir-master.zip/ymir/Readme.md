# _Mejora en el procesamiento de imagenes_

## Imagen Original


![png](examples/original.png)


> _Texto extraido del documento_

    PADPIETARIO
    LUIS NEY SANTOS CAMINERO
    
    yl tid dela Ley ye f bre de la Republi
    AMINERO;:dérnini¢ano, mayor:de oad; 3 (ak
    ‘tdentificada como 401462200071 : : Be4, 0100187186, i
    DUNAS: Il;-ubicada en Santo. Deminge Este; Santo Domingo, con un porcentaje depar as.
    ''y la parcela del 2.17% y:1 voto en:la asamblea de condémines, corformada por un SECTOR ‘PI OPIO ten fice
    SP-02-03-001, .Ubicado en el nivel 3, del bloque 02, destinado a Apartaments, ‘con: ui
    cuadrados y un. SECTOR GOMUN DE USO EXCLUSIVO identificado como SE-01-01-03
    01, déstinado a Parqueo, ‘con: una ‘superficie “de. 11:60: metros cuad :
    
    ee — consta en eladii 4 de fe
    
      
<br/>
<br/>

## Imagen Procesada

![png](examples/final.png)

> _Texto extraido del documento_


    LUIS NEY SANTOS CAMINERO
    
    En virtud de la Ley y en nombre de la Republica se declara TI TULAR DEL DERECHO DE RROPIEOAD a: LUIS NEY
    SANTOS CAMINERO, dorinicano, mayor de edad, soltero, Céduia de Identidad y Electoral. No.001-1360766-9 sobre la
    unidad-funcional B-4, identificada como 401462200071 : B-4, matricula'No.0100187186, del condominio RESIDENCIAL
    DUNAS II, ubicada en Santa Dominga Este, Santo Domingo, con un porcentaje de participacién sobre las areas comunes
    y la parcela del 2.17% y 1 voto en la asamblea de conddmines, conformada por un SECTOR PROPIO identificade como
    SP-02-03-001, ubicado en el nivel Q3, del bloque 02, destinado a Apartamento, con una superficie de 88.07 metros
    cuadrados y un SECTOR COMUN DE USO EXCLUSIVO identificado como SE-01-01-039, ubicado en el nivel 01, del
    bloque 01, destinado a Parqueo, con una superficie de 41.50 metros cuadrados. El derecho tiene su origen en
    CONSTITUCION-DE CONDOMINIO; gegdn consta en elsdooumento de fecha marzo del 2011,30ECLARATORIA,
    emitida por Ora.Keneris Manuel Vasquez Garrido, notariggublico de los del numero del Distrito Nacional, con matricula
    No.3694, inscrita en el lipro diario el 1 de julio dei 2011, a fas 2:06:00PM. Emitido el 8 de agosto del 2011. Dra. Rosabet
    Castillo R., Registradora de Titulos del Distrito Nacianal.
    
    nae ee
    
    atte betes seca brit he Da AIL SPO BOE EV Rees tate Meet
    

## Dependencies

 - opencv-python >= 4.2.0
 - Pillow >= 7.0.0
 - numpy >= 1.18.1


License
----

MIT
