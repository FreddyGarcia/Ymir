import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="ymir",
    version="0.0.2",
    author="Freddy Garcia Abreu",
    author_email="freddie-wpy@outlook.es",
    description="YMprove image Readability removing noise and unwanted details",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pypa/sampleproject",
    packages=setuptools.find_packages(),
    install_requires=[
        'opencv-python>=4.2.0.32',
        'Pillow>=7.0.0',
        'numpy>=1.18.1'
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)