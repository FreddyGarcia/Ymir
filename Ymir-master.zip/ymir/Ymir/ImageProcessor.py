
import cv2
from numpy import array

from PIL import ImageFilter, Image, ImageOps, ImageColor


class ImageProcessor():

    WHITE = ImageColor.getrgb('white')
    BLACK = ImageColor.getrgb('black')

    def __init__(self):
        self.image = None

    def open(self, image_path: str, image_format: str = 'RGB'):
        image = Image.open(image_path)
        image_rgb = image.convert(image_format)
        self.image = image_rgb

    def apply_filter(self, filter_name: str, **kwargs):
        _filter = getattr(ImageFilter, filter_name)
        self.image = self.image.filter(_filter(**kwargs))

    def gausian_filter(self, radius):
        return self.apply_filter('GaussianBlur', radius=radius)

    def apply_cleaner(self):
        '''
            All pixels no completely black are colored white
        '''
        image_array = array(self.image)
        r, g, b = image_array.T
        black_areas = (r != 0) & (b != 0) & (g != 0)
        image_array[...][black_areas.T] = ImageProcessor.WHITE
        self.image = Image.fromarray(image_array)

    def downscale_image(self, scale: float):
        '''
            scale: downscale percent.
        '''
        image_array = array(self.image)
        dim = tuple(int(a * scale) for a in reversed(image_array.shape[:2]))
        image_array = cv2.resize(image_array, dim, interpolation = cv2.INTER_AREA)
        self.image = Image.fromarray(image_array)
        
    def crop_image(self, params: dict):

        '''
            params:
                type: percent | pixels
                height: h_min, h_max
                width: w_min, w_max
        '''


        image_array = array(self.image)

        h_1, h_2 = params.get('height')
                
        if params.get('type') == 'pixels':
            w_1, w_2 = params.get('width', (None, None))               
            image_array = image_array[h_1:h_2:, w_1:w_2]
                
        elif params.get('type') == 'percent':
                
            w_1, w_2 = params.get('width', (0, 1))               
            image_h, image_w, rgb = image_array.shape

            h_1 = int(h_1 * image_h)
            h_2 = int(h_2 * image_h)
            w_1 = int(w_1 * image_w)
            w_2 = int(w_2 * image_w)
            
            image_array = image_array[h_1:h_2, w_1:w_2]
        
        self.image = Image.fromarray(image_array)

    def color_percent(self, color_rgb: tuple = BLACK) -> int:
        '''
            Retrieve the color percent of the current image.
        '''
        color_count = 0
        data = self.image.getdata()

        for pixel in data:
            if pixel == color_rgb:
                color_count += 1

        pixel_total = (data.size[0] * data.size[1])
        percent = (color_count / pixel_total)
        return percent

    def invert_image_color(self):
        '''
            `remove_isolated_pixels` method works with black background so this is necessary
            when images has white bg (most)
        '''
        self.image = ImageOps.invert(self.image)

    def remove_isolated_pixels(self, area_in_pixels = 30, adjacency = 8):
        '''
            area_in_pixels: remove shapes that are less than this number pixel area.
            adjacency: 4 = up, down, right, left | 8 = 4 + diagonal

            This function takes high cpu usage, recommended to use it with small/cropped images.
        '''
    
        WHITE_COLOR = 0

        image = self.image.convert('L')
        image_array = array(image)
        output = cv2.connectedComponentsWithStats(image_array, adjacency, cv2.CV_32S)

        num_stats = output[0]
        labels = output[1]
        stats = output[2]

        new_image = image_array.copy()

        for label in range(num_stats):
            if stats[label,cv2.CC_STAT_AREA] < area_in_pixels:
                new_image[labels == label] = WHITE_COLOR
        
        self.image = Image.fromarray(new_image)

    def __repr__(self):
        if self.image is None:
            return '<Image no set>'
        return str(self.image)
